function start(path)
{
  window.location=path;
}

function help()
{
  window.location="pages/help.html";
}

function about()
{
  window.location="pages/about.html";
}
function goback()
{
  window.location="../index.html";
}
